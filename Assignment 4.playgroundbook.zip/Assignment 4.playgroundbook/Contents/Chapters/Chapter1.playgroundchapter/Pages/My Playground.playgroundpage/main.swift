
//1. while ციკლის გამოყენებით, 1-დან 20-მდე დაბეჭდეთ ყველა კენტი რიცხვის ნამრავლი.
var num = 1
var sum = 1

while num < 20 {
    
    if num % 2 == 1 {
        sum*=num
    }
    num+=1

}

print(sum)

//2.შექმენით String ტიპის ცვლადი და ციკლის გამოყენებით შემოაბრუნეთ ის, მაგ: თუ გვაქვს “Test” უნდა მივიღოთ “tseT”

var word = "Test"
var lenOfWord = word.count
var invertedWord = ""

for i in stride(from: lenOfWord - 1, to: -1, by: -1) {
    invertedWord.append(word[word.index(word.startIndex, offsetBy: i)])
}
print(invertedWord)

//3.while loop-ისა და switch statement-ის გამოყენებით შექმენით უსასრულო შუქნიშანი, რომელიც ბეჭდავს შემდეგნაირად. "🔴->🌕->🟢->🔴->🌕..."

//let arrayOfEmojis: [String] = ["🔴", "🌕", "🟢"]
//var index = 0
//
//while true {
//    
//    switch index {
//    case 0:  print(arrayOfEmojis[0]+ "->", terminator: "")
//        index = 1
//    case 1:
//        print(arrayOfEmojis[1]+ "->", terminator: "")
//        index = 2
//    case 2:
//        print(arrayOfEmojis[2]+ "->", terminator: "")
//        index = 0
//    default:
//        break
//
//}
//}

//4.Taylor Swift-ის კონცერტის ბილეთები იყიდება, თუმცა რაოდენობა ძალიან შეზღუდულია. While loop-ის მეშვეობით შექმენით ბილეთების გაყიდვის სიმულაცია და ყოველ გაყიდულ ბილეთზე დაბეჭდეთ “ბილეთი გაყიდულია, დარჩენილია მხოლოდ X რაოდენობა”, მანამ სანამ ბილეთების რაოდენობა მიაღწევს 0-ს, რის შემდეგაც ბეჭდავთ - “ყველა ბილეთი გაყიდულია გელოდებით კონცერტზე”

var totalNumberOfTickets = 20
print("\nბილეთების რაოდენობა შეზღუდულია, იჩქარეთ!\n")

while totalNumberOfTickets != 0 {
    totalNumberOfTickets -= 1
    if totalNumberOfTickets == 0 {
            print("ყველა ბილეთი გაყიდულია, გელოდებით კონცერტზე")
        }
    else { 
        print("ბილეთი გაყიდულია, დარჩენილი რაოდენობაა: \(totalNumberOfTickets)")
    }
}





//5.შექმენით array, შეავსეთ ისინი ელემენტებით. შეამოწმეთ და დაბეჭდეთ: "array-ში ყველა ელემენტი განსხვავებულია" ან "array შეიცავს მსგავს ელემენტებს"  (array-ს ტიპს არაქვს მნიშვნელობა.)

var array5 = ["hi", "hii"]
var bool5 = false

for i in stride(from: 0, to: array5.count - 1, by: 1) {
    if array5[i] == array5[i+1] {
        bool5 = true
    }
    
}

print(bool5)

//6.დაწერეთ ქლოჟერი რომელიც გამოითვლის ორი რიცხვის სხვაობას და დააბრუნებს მიღებულ მნიშვნელობას

let substractionOfTwoNumbers: (Int, Int) -> Int = { (n1, n2) in
    return n1 - n2
}

print(substractionOfTwoNumbers(19,5))

//7.დაწერეთ ფუნქცია, რომელსაც გადააწვდით String ტიპის პარამეტრს. დაითვალეთ ამ პარამეტრში თანხმოვნების რაოდენობა და დაბეჭდეთ ის.


func consonants (word: String) -> Int {
    let vowels = ["ა", "ე", "ი", "ო", "უ"]
    var count = 0

    for i in word {
        if !vowels.contains(String(i)) {
            count += 1
        }
    }
    return count
}

print(consonants(word: "თამო"))

//8.შექმენით ორი Int-ების array, შეავსეთ პირველი array 8, 4, 9, 9, 0, 2, და მეორე array 1, 0, 9, 2, 3, 7, 0, 1 ამ რიცხვებით. გააერთიანეთ ეს ორი array ერთ დასორტილ array-ში, ანუ შედეგი უნდა მიიღოთ ასეთი: 0, 0, 0, 1, 1, 2, 2, 3, 4, 7, 8, 9, 9, არ გამოიყენოთ sorted() ან რაიმე სხვა უკვე არსებული მეთოდი swift-იდან. დაბეჭდეთ მიღებული დასორტილი array.



var arrayToSortOne: [Int] = [8, 4, 9, 9, 0, 2]
var arrayToSortTwo: [Int] = [1, 0, 9, 2, 3, 7, 0, 1]

